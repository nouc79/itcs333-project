<footer class="bg-light text-center text-lg-start mt-auto">
    <div class="text-center p-3" style="background-color: #e9ecef;">
        &copy; 2024 Room Booking System. All Rights Reserved.
    </div>
</footer>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>